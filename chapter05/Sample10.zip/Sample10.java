package chapter05;

import java.util.Arrays;

public class Sample10 {

    public static int getMax(int[] numbers) {
        int max = numbers[0];
        for (int number : numbers) {
            if (number > max) {
                max = number;
            }
        }
        return max;
    }

    public static int getMin(int[] numbers) {
        int min = numbers[0];
        for (int number : numbers) {
            if (number < min) {
                min = number;
            }
        }
        return min;
    }

    public static int getSum(int[] numbers) {
        int sum = 0;
        for (int number : numbers) {
            sum += number;
        }
        return sum;
    }

    public static double getAverage(int[] numbers) {
        int sum = 0;
        double avg = 0;
        for (int number : numbers) {
            sum += number;
        }
        avg = (double) sum / numbers.length;
        return avg;
    }

    public static int countEven(int[] numbers) {
        int count = 0;
        for (int number : numbers) {
            if (number % 2 == 0) {
                count++;
            }
        }
        return count;
    }

    public static int countOdd(int[] numbers) {
        int count = 0;
        for (int number : numbers) {
            if (number % 2 != 1) {
                count++;
            }
        }
        return count;
    }

    public static boolean contains(int[] numbers, int target) {
        boolean contain = false;
        for (int num : numbers) {
            if (num == target) {
                contain = true;
                break;
            }
        }
        return contain;
    }

    public static int findIndex(int[] numbers, int target) {

        for (int i = 0; i < numbers.length; i++) {
            if (numbers[i] == target) {
                return i;
            }
        }
        return -1;
    }

    public static int[] reverse(int[] numbers) {
        int[] reverseArray = new int[numbers.length];
        for (int i = 0; i < numbers.length; i++) {
            reverseArray[i] = numbers[numbers.length - 1 - i];
        }
        return reverseArray;
    }

    public static int[] copy(int[] numbers) {
        int[] copyArray = new int[numbers.length];
        for (int i = 0; i < numbers.length; i++) {
            copyArray[i] = numbers[i];
        }
        return copyArray;
    }

    public static void main(String[] args) {
        int[] numbers = { 70, 80, 90 };
        int[] reverse = reverse(numbers);
        int index = findIndex(numbers, 90);
        boolean contain = contains(numbers, 65);
        System.out.println(Arrays.toString(reverse));
        System.out.println(index);
        System.out.println(contain);

    }
}
